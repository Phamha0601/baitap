package PhamHa_23680571;

public class test {
	public static void main(String[] args) throws Exception {
		Tam t= new Tam("A", 1, 15);
		Hinhtrom h1= new Hinhtrom(10);
		System.out.println("Hinh tron tam: " +t.toString()+ h1.toString());
	}

}
